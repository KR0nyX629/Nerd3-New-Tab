const state = {
 mode:'focus',
 interval:null,
 timeLeft:1500,
 cycles:0,
 currentMode:'pomodoro',
 tasks:[],
 reminders:[],
 links:[],
 settings:{}
};
const el = id => document.getElementById(id);
const save = () => localStorage.setItem('techieState', JSON.stringify(state));
const load = () => {
 const stored = localStorage.getItem('techieState');
 if (!stored) return;
 try { const parsed = JSON.parse(stored); Object.assign(state, parsed); } catch(e){console.error(e);}
}
const format = s => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;
const updateTime = () => {
 const now = new Date();
 const h = now.getHours();
 const minutes = now.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
 el('timeText').textContent = minutes;
 el('statusText').textContent = state.mode === 'running' ? 'Focus in progress' : 'Ready to start';
 const greetingType = el('greetingMode').value || 'auto';
 const name = el('userName').value.trim() || 'techie';
 let greeting = 'Good morning';
 if (greetingType === 'auto') {
   if (h < 12) greeting='Good morning';
   else if (h < 18) greeting='Good afternoon';
   else greeting='Good evening';
 } else if (greetingType==='morning') greeting='Good morning';
 else if (greetingType==='evening') greeting='Good evening';
 else if (greetingType==='night') greeting='Good night';
 el('greetingText').textContent = `${greeting}, ${name}`;
}
const renderLinks = () => {
 const list = el('linksList');
 list.innerHTML='';
 state.links.forEach((link,i)=>{
   const item = document.createElement('div');
   item.className='link-item';
   const anchor = document.createElement('a');
   anchor.href=link.url;
   anchor.target='_blank';
   anchor.textContent=link.label || link.url;
   item.appendChild(anchor);
   const remove = document.createElement('button');
   remove.textContent='×';
   remove.onclick=()=>{ state.links.splice(i,1); save(); renderLinks(); };
   item.appendChild(remove);
   list.appendChild(item);
 });
 if(!state.links.length){ list.innerHTML='<div class="small">No quick links yet.</div>'; }
}
const renderTasks = () => {
 const list = el('taskList'); list.innerHTML='';
 state.tasks.forEach((task,i)=>{
   const item = document.createElement('div'); item.className='task-item';
   const label = document.createElement('span');
   label.textContent=task.text;
   item.appendChild(label);
   const done = document.createElement('button');
   done.textContent=task.done?'✓':'○';
   done.onclick=()=>{ task.done=!task.done; save(); renderTasks(); };
   item.appendChild(done);
   list.appendChild(item);
 });
 if(!state.tasks.length){ list.innerHTML='<div class="small">No tasks yet.</div>'; }
}
const renderReminders = () => {
 const list = el('remindersList'); list.innerHTML='';
 state.reminders.forEach((rem,i)=>{
   const item = document.createElement('div'); item.className='reminder-item';
   const label = document.createElement('span');
   label.textContent=rem.text;
   item.appendChild(label);
   const remove = document.createElement('button');
   remove.textContent='×';
   remove.onclick=()=>{ state.reminders.splice(i,1); save(); renderReminders(); };
   item.appendChild(remove);
   list.appendChild(item);
 });
 if(!state.reminders.length){ list.innerHTML='<div class="small">No reminders yet.</div>'; }
}
const applySettings = () => {
 document.documentElement.style.setProperty('--accent', el('accentColor').value || '#8ab4f8');
 document.body.style.backgroundImage = el('backgroundUrl').value ? `url("${el('backgroundUrl').value}")` : '';
 state.settings = {
   accent: el('accentColor').value,
   background: el('backgroundUrl').value,
   name: el('userName').value,
   greetingMode: el('greetingMode').value
 };
 save();
 updateTime();
}
const refresh = () => {
 el('pomodoroDisplay').textContent = format(state.timeLeft);
 updateTime();
 renderLinks();
 renderTasks();
 renderReminders();
 el('cycleCounter').textContent = state.cycles;
 el('accentColor').value = state.settings?.accent || '#8ab4f8';
 el('backgroundUrl').value = state.settings?.background || '';
 el('userName').value = state.settings?.name || 'techie';
 el('greetingMode').value = state.settings?.greetingMode || 'auto';
 applySettings();
}
const tick = () => {
 if (state.timeLeft <= 0) {
   clearInterval(state.interval);
   state.interval=null;
   state.mode='stopped';
   if(state.currentMode==='pomodoro'){ state.cycles += 1; state.currentMode='break'; state.timeLeft=300; el('statusText').textContent='Break time'; }
   else { state.currentMode='pomodoro'; state.timeLeft=1500; el('statusText').textContent='Back to focus'; }
   save(); refresh();
   return;
 }
 state.timeLeft -=1;
 el('pomodoroDisplay').textContent = format(state.timeLeft);
}
el('startStopBtn').addEventListener('click', ()=>{
 if(state.mode==='running'){ clearInterval(state.interval); state.interval=null; state.mode='stopped'; el('startStopBtn').textContent='Start'; }
 else { state.mode='running'; state.interval=setInterval(tick,1000); el('startStopBtn').textContent='Pause'; }
 save(); updateTime();
});
el('resetBtn').addEventListener('click', ()=>{
 clearInterval(state.interval); state.interval=null; state.mode='stopped'; state.currentMode='pomodoro'; state.timeLeft=1500; el('startStopBtn').textContent='Start'; save(); refresh();
});
el('modeBtn').addEventListener('click', ()=>{
 if(state.currentMode==='pomodoro'){ state.currentMode='break'; state.timeLeft=300; el('modeBtn').textContent='Focus'; }
 else { state.currentMode='pomodoro'; state.timeLeft=1500; el('modeBtn').textContent='Short Break'; }
 save(); refresh();
});
el('addTaskBtn').addEventListener('click', ()=>{
 const text = prompt('New task'); if(!text) return;
 state.tasks.push({text,done:false}); save(); renderTasks();
});
el('clearTasksBtn').addEventListener('click', ()=>{
 state.tasks = state.tasks.filter(task=>!task.done); save(); renderTasks();
});
el('addReminderBtn').addEventListener('click', ()=>{
 const text = prompt('Reminder'); if(!text) return;
 state.reminders.push({text}); save(); renderReminders();
});
el('resetRemindersBtn').addEventListener('click', ()=>{ state.reminders=[]; save(); renderReminders(); });
el('addLinkBtn').addEventListener('click', ()=>{
 const label = prompt('Link label','Read docs');
 const url = prompt('Link URL','https://');
 if(!url) return;
 state.links.push({label:label||url,url}); save(); renderLinks();
});
el('resetLinksBtn').addEventListener('click', ()=>{ state.links=[]; save(); renderLinks(); });
el('saveBrainBtn').addEventListener('click', ()=>{ localStorage.setItem('techieBrainDump', el('brainDump').value); });
el('saveSettingsBtn').addEventListener('click', ()=>{ applySettings(); alert('Settings saved'); });
window.addEventListener('keydown', e=>{ if(e.key==='s'&& (e.ctrlKey||e.metaKey)){ e.preventDefault(); el('saveBrainBtn').click(); }} );
window.addEventListener('load', ()=>{
 load();
 const brain = localStorage.getItem('techieBrainDump') || '';
 el('brainDump').value=brain;
 refresh();
 if(state.mode==='running'){ el('startStopBtn').click(); }
});
